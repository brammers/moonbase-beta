Moonbase Beta - Author's edition (c) 1992, 2006 Pete Hatton - Released as freeware.

This is the original Moonbase Beta when I finished the final compile and link of the code and graphics. It was pull off a 14 year old 5 1/4 inch floppy disk using Omniflop from http://www.shlock.co.uk/Utils/OmniFlop/OmniFlop.htm

I was god smacked the data survived!

This edition is called the Author's edition as it's the untouched version before Superior Software got their hands on it. It somehow got released, on Play It Again Sam. (But I never got paid for it!)

I found a version in the BBC lives website, but this version has been hacked for infinite energy! Bit daff if you ask me, as all you have to do is hold down the keys PBH on the screen where you set the keys, and infinite life mode will be enabled when you see a little message saying "That's me!"

Enjoy playing!

Pete "Brammers" Hatton - 17 October 2006.
